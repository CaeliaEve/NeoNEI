const Ajv = require('ajv');
const { decode } = require('@msgpack/msgpack');
const schema = structuredClone(require('./schema.json'));
// Each selected branch remains the Rust-generated strict schema. The tag only
// avoids evaluating unrelated variants and produces the relevant error path.
for (const definition of Object.values(schema.definitions)) {
  const variants = definition.oneOf;
  if (!Array.isArray(variants) || !variants.length) continue;
  const tags = variants.map(variant => variant.properties?.kind?.enum);
  if (!variants.every((variant, index) => variant.type === 'object' && variant.required?.includes('kind')
      && Array.isArray(tags[index]) && tags[index].length === 1 && typeof tags[index][0] === 'string')) continue;
  if (new Set(tags.map(tag => tag[0])).size !== variants.length) continue;
  definition.type = 'object';
  definition.discriminator = { propertyName: 'kind' };
}
exports.formats = Object.freeze(Object.fromEntries([['source', 'SourceManifest'], ['catalog', 'Manifest']].map(([name, type]) => {
  const fields = schema.definitions[type].properties;
  return [name, Object.freeze({ name: fields.format.enum[0], revision: fields.revision.enum[0] })];
})));
exports.collections = Object.freeze(schema.definitions.Table.oneOf.map(table => table.properties.kind.enum[0]).sort());
exports.topicKinds = Object.freeze(schema.definitions.TopicKind.enum);

const ajv = new Ajv({ strict: true, allowUnionTypes: true, discriminator: true });
for (const [name, minimum, maximum] of [
  ['uint8', 0, 255], ['uint16', 0, 65535], ['uint32', 0, 4294967295],
  ['int8', -128, 127], ['int16', -32768, 32767], ['int32', -2147483648, 2147483647],
  ['uint64', 0, Number.MAX_SAFE_INTEGER],
]) ajv.addFormat(name, { type: 'number', validate: value =>
  Number.isSafeInteger(value) && value >= minimum && value <= maximum });
ajv.addFormat('double', { type: 'number', validate: Number.isFinite });
ajv.addFormat('float', { type: 'number', validate: value =>
  Number.isFinite(value) && Number.isFinite(Math.fround(value)) });
ajv.addSchema(schema, 'elysium');
const validators = Object.fromEntries(['Manifest', 'Pointer'].map(name =>
  [name, ajv.compile({ $ref: `elysium#/definitions/${name}` })]));
// Validate the declared table variant once, instead of testing every table kind
// and every row against unrelated domain schemas. Compile each used kind lazily.
const tableVariants = new Map(schema.definitions.Table.oneOf.map((table, index) =>
  [table.properties.kind.enum[0], index]));
const tableValidators = new Map();

function validationError(name, errors) {
  const details = [...new Set((errors ?? []).map(error =>
    `${error.instancePath || '/'} ${error.message}`).map(message =>
    message.length > 256 ? message.slice(0, 253) + '...' : message))];
  const kept = details.slice(0, 6);
  const remaining = details.length - kept.length;
  return new Error(`Invalid ${name.toLowerCase()}: ${kept.join('; ')}${remaining ? `; ${remaining} additional validation details omitted` : ''}`);
}

function assert(name, value) {
  const validate = validators[name];
  if (!validate(value)) throw validationError(name, validate.errors);
}

function assertTable(value) {
  const kind = value !== null && typeof value === 'object' && !Array.isArray(value) ? value.kind : undefined;
  if (!tableVariants.has(kind)) throw new Error('Invalid table: unknown or missing kind');
  let validate = tableValidators.get(kind);
  if (!validate) {
    validate = ajv.compile({ $ref: `elysium#/definitions/Table/oneOf/${tableVariants.get(kind)}` });
    tableValidators.set(kind, validate);
  }
  if (!validate(value)) throw validationError('Table', validate.errors);
}

exports.assertManifest = value => assert('Manifest', value);
exports.assertPointer = value => assert('Pointer', value);
exports.assertTable = assertTable;
exports.decodeTable = (bytes, kind) => {
  if (!(bytes instanceof Uint8Array) || bytes.length > 16 * 1024 * 1024) throw new Error('Catalog table exceeds 16 MiB');
  const table = decode(bytes, { maxStrLength: 1024 * 1024, maxBinLength: 0,
    maxArrayLength: 1000000, maxMapLength: 131072, maxExtLength: 0, useBigInt64: true });
  assertTable(table);
  if (kind !== undefined && table.kind !== kind) throw new Error('Catalog table kind does not match its manifest');
  if ((table.kind === 'views' || table.kind === 'tracks') && table.records.length
      || (table.kind === 'recipes' || table.kind === 'categories') && table.records.some(row => row.view != null)) {
    throw new Error('Semantic Catalog cannot contain native recipe GUI');
  }
  return table;
};

const encoder = new TextEncoder();
function compare(left, right) {
  const a = encoder.encode(left), b = encoder.encode(right);
  for (let index = 0; index < Math.min(a.length, b.length); index++) {
    if (a[index] !== b[index]) return a[index] - b[index];
  }
  return a.length - b.length;
}

function canonical(value, depth = 0) {
  if (depth > 64) throw new Error('Canonical JSON exceeds nesting limit');
  if (value === null) return 'null';
  if (typeof value === 'number') {
    if (!Number.isFinite(value) || Number.isInteger(value) && !Number.isSafeInteger(value))
      throw new Error('JSON quantities must be exact integer strings; native decimals must be finite');
    if(value===0)return '0';
    const negative=value<0;
    const [mantissa,exponent='0']=String(Math.abs(value)).toLowerCase().split('e');
    const [integer,fraction='']=mantissa.split('.');
    const leading=(integer+fraction).replace(/^0+/,'');
    const digits=leading.replace(/0+$/,'');
    const scale=fraction.length-Number(exponent)-(leading.length-digits.length);
    if(digits.length>100||Math.abs(scale)>100)throw new Error('JSON number exceeds native canonical range');
    const point=digits.length-scale;
    const decimal=scale<=0?digits+'0'.repeat(-scale):point<=0?'0.'+'0'.repeat(-point)+digits:digits.slice(0,point)+'.'+digits.slice(point);
    return (negative?'-':'')+decimal;
  }
  if (typeof value === 'string' || typeof value === 'boolean') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(entry => canonical(entry, depth + 1)).join(',')}]`;
  if (typeof value === 'object') return `{${Object.keys(value).sort(compare).map(key =>
    `${JSON.stringify(key)}:${canonical(value[key], depth + 1)}`).join(',')}}`;
  throw new Error('Unsupported canonical JSON value');
}
exports.canonical = canonical;
